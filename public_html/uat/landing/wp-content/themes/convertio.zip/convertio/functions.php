<?php

/**
 * uicore functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package uicore-theme
 */
defined('ABSPATH') || exit;
$uicore_settings = get_option( 'uicore_theme_options_admin', [] );
$uicore_settings['purchase_info'] = [
	'code' => '*****'
];
update_option( 'uicore_theme_options_admin', $uicore_settings );
update_option( 'uicore_connect', array('url' => get_site_url(), 'token' => '********-****-****-****-************'));
//Global Constants
define('UICORE_THEME_VERSION', '2.1.0');
define('UICORE_THEME_NAME', 'Convertio');
define('UICORE_FRAMEWORK_VERSION', '4.2.0');


$uicore_includes = array(
	'/setup.php',
	'/default.php',
	'/template-tags.php',
	'/plugin-activation.php'
);

foreach ($uicore_includes as $file) {
	require_once get_template_directory() . '/inc' . $file;
}


//Required
if ( ! isset( $content_width ) ) {
	$content_width = 1000;
}
if ( is_singular() ) {
	wp_enqueue_script( "comment-reply" );
}

add_filter('uicore_settings_default_admin', 'uicore_default_admin_options');
function uicore_default_admin_options($default) {
	$settings = array(
		'pFont' => [
						'f' => 'Outfit',
						'st' => '600',
					],
					'sFont' => [
						'f' => 'Outfit',
						'st' => '500',
					],
					'tFont' => [
						'f' => 'Outfit',
						'st' => 'normal',
					],
					'aFont' => [
						'f' => 'Outfit',
						'st' => '500',
					],
	);
	return wp_parse_args($settings, $default);
}

add_filter('uicore_settings_default_front', 'uicore_default_front_options');
function uicore_default_front_options($default) {
	$settings = [
		'pColor'					=> '#FF5D0C',
		'sColor'					=> '#1D1D1F',
		'aColor'					=> '#D1345B',
		'hColor'					=> '#0B0A27',
		'bColor'					=> '#6E7A84',
		'dColor'					=> '#1D1D1F',
		'lColor'					=> '#F8FCFC',
		'logo'						=> 'https://convertio.uicore.co/wp-content/uploads/2022/03/convertio-logo.webp',
		'fav'						=> 'https://convertio.uicore.co/wp-content/uploads/2022/03/Convertio-Favicon.png',
		'pagetitle_bg' 				=> [
			'type' 			=> 'gradient',
			'solid' 		=> 'Light Neutral',
			'gradient' 		=> [
				'angle' 		=> '180',
				'color1' 		=> '#ffeede',
				'color2' 		=> '#ffffff',
			],
			'image' 		=> [
				'url' 			=> '',
				'attachment' 	=> 'scroll',
				'position' 		=> [
					'd' => 'bottom center',
					't' => 'center center',
					'm' => 'center center',
				],
				'repeat' 		=> 'no-repeat',
				'size' 			=> [
					'd' => 'cover',
					't' => 'cover',
					'm' => 'contain',
				],
			],
		],
		'pagetitle_color'			=> 'Headline'
	];
	return wp_parse_args($settings, $default);
}

//disable element pack self update 
function ui_disable_plugin_updates( $value ) {

    $pluginsToDisable = [
        'bdthemes-element-pack/bdthemes-element-pack.php',
        'metform-pro/metform-pro.php'
    ];

    if ( isset($value) && is_object($value) ) {
        foreach ($pluginsToDisable as $plugin) {
            if ( isset( $value->response[$plugin] ) ) {
                unset( $value->response[$plugin] );
            }
        }
    }
    return $value;
}
add_filter( 'site_transient_update_plugins', 'ui_disable_plugin_updates' );