<?php
$this->load->helper('url');
$this->load->view('header/header'); ?>

<div class='page-header  page-header_align_left'
   style="background-image:url(assets/images/page_title_bg.png); background-size:cover; background-repeat:no-repeat; background-attachment:scroll; background-position:center bottom; height:auto; margin-bottom:0px; padding-top:90px; padding-bottom:50px;">
   <div class='page-header_wrapper'>
      <div class='wgl-container'>
         <div class='page-header_content'>
            <h1 class='page-header_title' style="color:#161616; font-size:42px; line-height:72px;">Our Videos</h1>
            <div class='page-header_breadcrumbs' style="color:#8b9baf; font-size:16px; line-height:24px;margin-top: 0;">
               <div class="breadcrumbs"><a href="<?php echo base_url('') ?>" class="home">Home</a> <span
                     class="divider"></span> <span class="current">Our Videos</span></div>
               <!-- .breadcrumbs -->
            </div>
         </div>
      </div>
   </div>
</div>
<main id="main">
   <div class="wgl-container">
      <div class="video-grid">
         <?php 
         $videos = [
            ['title' => "Why Choose an 'Intelligent' Field Force Automation Solution?", 'link' => 'https://www.youtube.com/embed/EfdpKdjC6ks'],
            ['title' => "A Word By The Founders", 'link' => 'https://www.youtube.com/embed/1tHRoGoXhXc'],
            ['title' => "IMPRINT AI Capabilities", 'link' => 'https://www.youtube.com/embed/LAClSXZcvvs'],
            ['title' => "Imprint Campaign Management video", 'link' => 'https://www.youtube.com/embed/2Hp7eljtKfk'],
            ['title' => "Game-changing Features to Empower Field Agents", 'link' => 'https://www.youtube.com/embed/_hmiTWIpCDs'],
            ['title' => "Unlock Unparalleled Customer Satisfaction with Imprint Field Service Management Software!", 'link' => 'https://www.youtube.com/embed/26NwEjEvoLE'],
            ['title' => "Unlock Your Sales Potential with Imprint!", 'link' => 'https://www.youtube.com/embed/SiG6OgD-5Bg']
         ];
         
         $videos = array_reverse($videos);
         
         foreach ($videos as $video) { ?>
            <div class="video-item">
               <iframe width="350" height="287" src="<?php echo $video['link']; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
               <h3><?php echo $video['title']; ?></h3>
            </div>
         <?php } ?>
      </div>
   </div>
</main>

<style>
.video-grid {
   display: flex;
   flex-wrap: wrap;
   gap: 20px;
   justify-content: space-around;
}
.video-item {
   text-align: center;
   max-width: 320px;
   margin-bottom: 30px; 
}
.video-item iframe {
   border-radius: 30px; 
   overflow: hidden; 
}
.video-item h3 {
   margin-top: 10px;
   font-size: 24px;
   line-height: 36px; 
   font-weight: 700;
   color: #313131;
   text-align: left;
}
</style>


<?php $this->load->view('footer/footer'); ?>
