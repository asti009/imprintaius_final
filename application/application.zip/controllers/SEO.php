<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Seo extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
    }


    public function field_force_management_software()
    {
        $this->load->view('body/seo/field-force-management-software');
    }
}
